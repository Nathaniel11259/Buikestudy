let level='',subject='',qIndex=0,score=0,selected=null;
const data={
 Primary:{Maths:{title:'Addition',text:'Addition means putting numbers together to find a total. For example, 3 + 2 = 5. The numbers being added are called addends, and the answer is the sum.',qs:[['What is 3 + 2?',['4','5','6'],1],['What is 7 + 1?',['8','9','7'],0]]},
 English:{title:'Nouns',text:'A noun is a word used to name a person, place, animal, thing, or idea. Examples include teacher, school, dog, book, and happiness.',qs:[['Which word is a noun?',['Run','School','Quickly'],1]]},
 Science:{title:'Living Things',text:'Living things need resources to survive and can grow, reproduce, and respond to their surroundings. Plants and animals are examples.',qs:[['Which is a living thing?',['Rock','Plant','Chair'],1]]}},
 Secondary:{Maths:{title:'Algebra Basics',text:'Algebra uses letters to represent unknown numbers. In x + 3 = 8, subtract 3 from both sides to find x = 5.',qs:[['If x + 3 = 8, what is x?',['3','5','11'],1]]},
 English:{title:'Parts of Speech',text:'Words can have different roles in sentences. Common parts of speech include nouns, verbs, adjectives, adverbs, pronouns, and prepositions.',qs:[['Which is a verb?',['Jump','Blue','School'],0]]},
 Science:{title:'Cells',text:'A cell is the basic unit of life. Plant and animal cells have structures that help them perform important functions.',qs:[['What is the basic unit of life?',['Cell','Organ','Bone'],0]]}},
 University:{Maths:{title:'Functions',text:'A function maps each input to exactly one output. It is often written as f(x). For example, if f(x)=2x, then f(3)=6.',qs:[['If f(x)=2x, what is f(3)?',['5','6','8'],1]]},
 English:{title:'Academic Reading',text:'Academic reading involves identifying the main idea, supporting evidence, key terms, and the author’s purpose. Active notes can improve understanding.',qs:[['What should you identify first?',['Main idea','Page color','Font size'],0]]},
 'Computer Science':{title:'Algorithms',text:'An algorithm is a clear sequence of steps used to solve a problem or complete a task. Good algorithms are precise and finite.',qs:[['What is an algorithm?',['A sequence of steps','A computer screen','A password'],0]]}}
};

let state=JSON.parse(localStorage.getItem('buikeStudyState')||'null')||{user:null,completed:[],quizzes:[],bookmarks:[]}; state.bookmarks=state.bookmarks||[];
function save(){localStorage.setItem('buikeStudyState',JSON.stringify(state));updateProgress()}
function show(id){document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active');window.scrollTo(0,0)}
function goHome(){updateProgress();show('home')}
function showProfile(){renderProfile();show('profile')}
function showLevel(l){level=l;document.getElementById('levelTitle').textContent=l+' Subjects';let list=document.getElementById('subjectList');list.innerHTML='';Object.keys(data[l]).forEach(s=>{let b=document.createElement('button');b.innerHTML=`📖 <b>${s}</b><span>Lessons and practice ${isComplete(l,s)?'✓ Completed':''}</span>`;b.onclick=()=>openLesson(s);list.appendChild(b)});show('subjects')}
function showSubjects(){show('subjects')}
function openLesson(s){subject=s;document.getElementById('lessonTitle').textContent=subject;document.getElementById('lessonHeading').textContent=data[level][subject].title;document.getElementById('lessonText').textContent=data[level][subject].text;show('lesson');updateBookmarkButton()}
function showLesson(){show('lesson')}
function lessonKey(){return level+'|'+subject}
function isComplete(l,s){return state.completed.includes(l+'|'+s)}
function completeLesson(){if(!isComplete(level,subject)){state.completed.push(lessonKey());save()}alert('Lesson saved as completed! ✓');showSubjects();showLevel(level)}
function updateProgress(){let total=0;Object.values(data).forEach(x=>total+=Object.keys(x).length);let done=state.completed.length;let pct=Math.round(done/total*100);document.getElementById('progressLabel').textContent=pct+'%';document.getElementById('progressBar').style.width=pct+'%';document.getElementById('progressDetails').textContent=`${done} lesson${done===1?'':'s'} completed`;(document.getElementById('welcome')||{}).querySelector?.('h2') && (document.getElementById('welcome').querySelector('h2').textContent=state.user?`Welcome back, ${state.user.name} 👋`:'Welcome to BuikeStudy 👋')}
let quizQuestions=[], currentAnswers=[], quizMode='Practice', lastQuiz=null;

function buildQuestions(){
  return data[level][subject].qs.map((q,i)=>({question:q[0],options:q[1],answer:q[2],number:i+1}));
}
function startQuiz(mode='Practice'){
  quizMode=mode; quizQuestions=buildQuestions(); qIndex=0; score=0; selected=null; currentAnswers=[];
  document.getElementById('quizTitle').textContent=mode==='Practice'?'Practice Test':'Quick Quiz';
  document.getElementById('quizModeBadge').textContent=mode;
  renderQuestion(); show('quiz');
}
function renderQuestion(){
  const q=quizQuestions[qIndex];
  selected=null;
  document.getElementById('quizProgress').textContent=`Question ${qIndex+1} of ${quizQuestions.length}`;
  document.getElementById('quizTrackBar').style.width=((qIndex+1)/quizQuestions.length*100)+'%';
  document.getElementById('questionBox').innerHTML=`<h3>${q.question}</h3>`+
    q.options.map((o,i)=>`<button class="option" onclick="choose(${i})">${o}</button>`).join('');
  document.getElementById('nextBtn').textContent=qIndex===quizQuestions.length-1?'Finish Test':'Next Question';
}
function choose(i){
  selected=i;
  document.querySelectorAll('.option').forEach((b,n)=>b.classList.toggle('selected',n===i));
}
function nextQuestion(){
  if(selected===null){alert('Please choose an answer.');return}
  const q=quizQuestions[qIndex];
  currentAnswers.push({question:q.question,chosen:selected,chosenText:q.options[selected],correct:q.answer,correctText:q.options[q.answer],isCorrect:selected===q.answer});
  if(selected===q.answer)score++;
  if(qIndex<quizQuestions.length-1){qIndex++;renderQuestion()}
  else finishQuiz();
}
function finishQuiz(){
  const total=quizQuestions.length,pct=Math.round(score/total*100);
  lastQuiz={level,subject,mode:quizMode,score,total,pct,answers:currentAnswers.slice(),date:new Date().toISOString()};
  state.quizzes.push({level,subject,score,total,pct,date:lastQuiz.date,mode:quizMode});
  save();
  document.getElementById('bigScore').textContent=`${score}/${total} • ${pct}%`;
  document.getElementById('scoreText').textContent=`${subject} — ${quizMode}`;
  document.getElementById('resultMessage').textContent=pct>=80?'Excellent work! 🌟':pct>=50?'Good effort! Keep practising. 💪':'Keep going — review the lesson and try again. 📚';
  show('result');
}
function showResult(){show('result')}
function showReview(){
  const box=document.getElementById('reviewList'); box.innerHTML='';
  if(!lastQuiz){box.innerHTML='<p>No test to review.</p>';show('review');return}
  lastQuiz.answers.forEach((a,i)=>{
    box.innerHTML+=`<div class="reviewItem ${a.isCorrect?'correct':'wrong'}">
      <small>Question ${i+1}</small><b>${a.question}</b>
      <span class="tag ${a.isCorrect?'correctTag':'wrongTag'}">${a.isCorrect?'✓ Correct':'✗ Incorrect'}</span>
      <p>Your answer: <b>${a.chosenText}</b></p>
      ${a.isCorrect?'':'<p>Correct answer: <b>'+a.correctText+'</b></p>'}
    </div>`;
  });
  show('review');
}
function showPractice(){
  const list=document.getElementById('practiceList'); list.innerHTML='';
  Object.keys(data).forEach(l=>{
    Object.keys(data[l]).forEach(s=>{
      const b=document.createElement('button');
      b.innerHTML=`📝 <b>${l} — ${s}</b><span>${data[l][s].qs.length} question${data[l][s].qs.length===1?'':'s'} • Practice test</span>`;
      b.onclick=()=>{level=l;subject=s;startQuiz('Practice')};
      list.appendChild(b);
    });
  });
  show('practice');
}

function showSearch(){
  document.getElementById('searchInput').value='';
  document.getElementById('searchResults').innerHTML='<p class="muted">Start typing to search lessons and subjects.</p>';
  show('search');
  setTimeout(()=>document.getElementById('searchInput').focus(),50);
}
function allLessons(){
  const items=[];
  Object.keys(data).forEach(l=>Object.keys(data[l]).forEach(s=>{
    const d=data[l][s];
    items.push({level:l,subject:s,title:d.title,text:d.text,qs:d.qs.length});
  }));
  return items;
}
function runSearch(){
  const term=document.getElementById('searchInput').value.trim().toLowerCase();
  const box=document.getElementById('searchResults');
  if(!term){box.innerHTML='<p class="muted">Start typing to search lessons and subjects.</p>';return}
  const results=allLessons().filter(x=>
    `${x.level} ${x.subject} ${x.title} ${x.text}`.toLowerCase().includes(term));
  if(!results.length){box.innerHTML='<div class="lesson"><h3>No results found</h3><p>Try another subject, topic, or keyword.</p></div>';return}
  box.innerHTML='';
  results.forEach(x=>{
    const b=document.createElement('button');
    b.innerHTML=`🔎 <b>${x.subject} — ${x.title}</b><span>${x.level} • ${x.qs} quiz question${x.qs===1?'':'s'}</span>`;
    b.onclick=()=>{level=x.level;openLesson(x.subject)};
    box.appendChild(b);
  });
}
function bookmarkKey(){return lessonKey()}
function isBookmarked(l=level,s=subject){return state.bookmarks.includes(l+'|'+s)}
function toggleBookmark(){
  const key=bookmarkKey(), i=state.bookmarks.indexOf(key);
  if(i>=0)state.bookmarks.splice(i,1);else state.bookmarks.push(key);
  save(); updateBookmarkButton();
}
function updateBookmarkButton(){
  const b=document.getElementById('bookmarkBtn');
  if(!b)return;
  const saved=isBookmarked();
  b.classList.toggle('saved',saved);
  b.textContent=saved?'🔖':'🔖';
  b.title=saved?'Remove bookmark':'Save lesson';
}
function showBookmarks(){
  const box=document.getElementById('bookmarkList');box.innerHTML='';
  if(!state.bookmarks.length){
    box.innerHTML='<div class="lesson"><h3>No bookmarks yet</h3><p>Open a lesson and tap the 🔖 button to save it here.</p></div>';
    show('bookmarks');return;
  }
  state.bookmarks.forEach(key=>{
    const parts=key.split('|'),l=parts[0],s=parts.slice(1).join('|');
    if(!data[l]||!data[l][s])return;
    const d=data[l][s],b=document.createElement('button');
    b.innerHTML=`🔖 <b>${s} — ${d.title}</b><span>${l} • ${d.text.slice(0,75)}...</span>`;
    b.onclick=()=>{level=l;openLesson(s)};
    box.appendChild(b);
  });
  show('bookmarks');
}
function renderProfile(){document.getElementById('profileName').textContent=state.user?state.user.name:'Student';document.getElementById('profileEmail').textContent=state.user?state.user.email:'Create a local student account';document.getElementById('lessonsDone').textContent=state.completed.length;document.getElementById('quizzesDone').textContent=state.quizzes.length;let avg=state.quizzes.length?Math.round(state.quizzes.reduce((a,q)=>a+q.pct,0)/state.quizzes.length):0;document.getElementById('avgScore').textContent=avg+'%';let area=document.getElementById('authArea');if(state.user){area.innerHTML=`<div class="auth"><h3>Your account</h3><p class="note">Your progress is saved on this device.</p><button class="logout" onclick="logout()">Log out</button></div>`}else{area.innerHTML=`<div class="auth"><h3>Create your student profile</h3><input id="nameInput" placeholder="Your name"><input id="emailInput" type="email" placeholder="Email (optional)"><button onclick="createAccount()">Create Account</button><p class="note">This Version 1 account is stored only on this device.</p></div>`}}
function createAccount(){let name=document.getElementById('nameInput').value.trim();let email=document.getElementById('emailInput').value.trim();if(!name){alert('Please enter your name.');return}state.user={name,email};save();renderProfile();updateProgress()}
function logout(){state.user=null;save();renderProfile();updateProgress()}
updateProgress();


// =========================
// Step 7 — AI Study Helper
// =========================
function showAIHelper(){
  showScreen('aiHelper');
  const input=document.getElementById('aiInput');
  if(input) setTimeout(()=>input.focus(),50);
}

function setAIExample(text){
  const input=document.getElementById('aiInput');
  if(input){
    input.value=text;
    input.focus();
  }
}

function addAIMessage(text, who='bot'){
  const chat=document.getElementById('aiChat');
  if(!chat) return;
  const div=document.createElement('div');
  div.className='aiMessage '+who;
  const safe=text.replace(/\n/g,'<br>');
  div.innerHTML = who==='bot'
    ? '<strong>BuikeStudy Tutor</strong><p>'+safe+'</p>'
    : '<p>'+safe+'</p>';
  chat.appendChild(div);
  chat.scrollTop=chat.scrollHeight;
}

function normalizeAIText(text){
  return text.toLowerCase().replace(/[^\w\s]/g,' ').replace(/\s+/g,' ').trim();
}

function localTutor(question){
  const q=normalizeAIText(question);

  if(!q) return "Please type a study question first.";

  if(q.includes('photosynthesis')){
    return "Photosynthesis is the process plants use to make food. In simple terms: plants use sunlight, water and carbon dioxide to produce glucose (food) and release oxygen. It mainly happens in the leaves, inside structures called chloroplasts.";
  }

  if(q.includes('fraction')){
    return "A fraction shows part of a whole. The top number is the numerator and the bottom number is the denominator. For example, 3/4 means 3 parts out of 4 equal parts.";
  }

  if(q.includes('algebra')){
    return "Algebra uses letters to represent unknown numbers. Example: x + 5 = 12. Subtract 5 from both sides, so x = 7. The key idea is to keep both sides balanced.";
  }

  if(q.includes('newton') || q.includes('force')){
    return "Newton’s laws help explain motion. The second law is often written as F = ma: force equals mass multiplied by acceleration. A larger force can produce greater acceleration when mass stays the same.";
  }

  if(q.includes('grammar') || q.includes('noun')){
    return "A noun is a word used to name a person, place, thing or idea. Examples include teacher, Nigeria, book and honesty. Try finding the nouns in a sentence and then identify what each one names.";
  }

  if(q.includes('computer') || q.includes('programming') || q.includes('coding')){
    return "Computer programming means writing instructions that a computer can follow. Most programs use variables, conditions, loops and functions to solve problems step by step.";
  }

  if(q.includes('quiz') || q.includes('practice questions') || q.includes('test me')){
    return "Quick practice:\n1. What is 12 × 8?\n2. What gas do plants release during photosynthesis?\n3. What is a noun?\n\nTry answering without looking anything up. Then ask me to check your answers.";
  }

  if(q.includes('revise') || q.includes('revision') || q.includes('study plan')){
    return "Try this revision routine: 1) choose one topic, 2) read the key idea, 3) close your notes and explain it from memory, 4) answer 5 practice questions, and 5) review the questions you missed. Short focused sessions can make revision easier.";
  }

  if(q.includes('hello') || q.includes('hi')){
    return "Hello! 👋 I’m ready to help you study. Ask me to explain a topic, give you practice questions, or help you revise.";
  }

  return "I can help with common school topics in this offline prototype. Try asking about mathematics, English, science, physics, computer studies, photosynthesis, fractions, algebra, or ask for practice questions.";
}

function askAI(event){
  event.preventDefault();
  const input=document.getElementById('aiInput');
  if(!input) return;
  const question=input.value.trim();
  if(!question) return;

  addAIMessage(question,'user');
  input.value='';

  const answer=localTutor(question);
  setTimeout(()=>addAIMessage(answer,'bot'),180);
}
