# BuikeStudy — GitHub APK Builder

## Upload with your phone
Upload the CONTENTS of this folder to the ROOT of your GitHub repository named `BuikeStudy`.

After committing the files:
1. Open the repository.
2. Tap **Actions**.
3. Tap **Build BuikeStudy APK**.
4. Tap **Run workflow**.
5. Choose `main`.
6. Tap **Run workflow** again.
7. Wait for the build to finish.
8. Open the completed run.
9. Under **Artifacts**, download `BuikeStudy-debug-apk`.
10. Extract the downloaded ZIP and install `app-debug.apk`.

This produces a debug APK for testing. Google Play publishing requires a signed release build/AAB.

Never put passwords, API keys, or private signing keys in GitHub.
