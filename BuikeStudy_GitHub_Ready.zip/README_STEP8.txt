BuikeStudy — Step 8 Android App Project

This folder is an Android Studio project wrapper for the BuikeStudy web app.

WHAT STEP 8 ADDS
- Android application project structure
- BuikeStudy app label
- Portrait phone layout
- WebView that loads the BuikeStudy learning app
- JavaScript and browser storage enabled, so the existing local profile,
  progress, quiz history and bookmarks can continue working on the device
- Offline app assets bundled inside the Android application

IMPORTANT
This is an Android-ready source project, not a signed APK. An APK must be
built with Android Studio/Gradle before it can be installed on an Android
phone.

HOW TO BUILD
1. Install Android Studio on a computer.
2. Open the "android" folder in Android Studio.
3. Let Gradle finish syncing.
4. Select Build > Build APK(s).
5. Android Studio will create the APK in the app/build/outputs/apk/debug/
   folder.

The current app is still a prototype. Step 8 does not add an online server,
Google Play publishing, or a real cloud AI service.
